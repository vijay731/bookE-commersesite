<!DOCTYPE html>
<html>
<head>
<title>Book E-commerse Site</title>
<link rel="stylesheet" href="homecss.css">
</head>
<body>
<div class="topnav-right">
<a href="about.php">About Us</a>
</div>
<h1>Book 📖 E-commerse Site</h1>
<font size="5">
<a href="uploadbook.php">UPLOAD BOOK</a><br><br>
<a href="purchasebook.php">PURCHASE BOOK</a><br><br>
<a href="deletebook.php">DELETE</a>
</font>
</body>

</html>