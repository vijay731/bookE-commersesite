<!DOCTYPE html>
<html>
<head>
<title>About Us</title>
<link rel="stylesheet" href="aboutcss.css">
</head>
<body>
<h1 align="center">Book 📖 E-commerse Site</h1>
<div><font size="5">
<p class="style1">This is a website about Book E-commerse,here you can upload books,purchase books,delete books and updates books.<br>
here you can purchase book by using contact detail.</p>
<h5 align=center>GO TO HOME PAGE  <a href="home.php">Click Here</a></h3>
<img class="pic1" src="book-vector-by-vexels.png">
<img class="pic2" src="book-vector-by-vexels.png">
</font>
</div>
</body>
</html>